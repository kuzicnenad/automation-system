#ifndef Seg_h
#define Seg_h

#include "Arduino.h"

void Init7Seg();
void WriteNum(const int Num);
void TurnDspOn(const int DspNo);
void TurnDspOff(const int DspNo);

#endif Seg_h
