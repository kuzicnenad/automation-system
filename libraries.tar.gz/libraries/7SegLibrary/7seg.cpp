#include "7Seg.h"
const int SevenSegArr[10]={0xFC, 0x60, 0xDA, 0xF2,0x66,0xB6,0xBE,0xE0,0xFE, 0xE6};
const int DispNo[4]= {0x08, 0x04, 0x02, 0x01};
void Init7Seg()
{  
    DDRB |= 0x0F;
    DDRD |= 0xFF;
    PORTB = 0x0F;
    PORTD = 0x00; 
}
void WriteNum(const int Num){
  PORTD = SevenSegArr[Num];
}
void TurnDspOn(const int DspNo)
{
  PORTB &= ~DispNo[DspNo-1];  
}
void TurnDspOff(const int DspNo)
{
  PORTB |= DispNo[DspNo-1];  
}
