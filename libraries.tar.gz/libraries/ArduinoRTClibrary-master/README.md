# ArduinoRTClibrary
An easy to use real time clock library for Arduino, it was in the public domain, but not on GitHub, so I uploaded it.
